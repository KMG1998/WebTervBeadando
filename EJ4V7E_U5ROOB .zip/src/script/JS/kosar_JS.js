function removeTermekFromKosar(termek) {
    document.getElementsByName(termek).item(0).remove();
}